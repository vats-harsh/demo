﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Drawing;

namespace E_VISA
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string role;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("initial catalog=E-VISA;integrated security=true ;server=VDILEWVPNTH510;");
            cn.Open();
            SqlCommand cmd;
            int i;
            if (DropDownList2.SelectedItem.Text == "ADMIN")
            {
                cmd = new SqlCommand("select count(*) from Admindtl where Aemail= '" + TextBox2.Text.Trim() + "' and Apwd= '" + TextBox1.Text.Trim() + "'", cn);
                i = Convert.ToInt32(cmd.ExecuteScalar());
                Response.Write(i);
                if (i == 1)
                {

                    Response.Redirect("ADMINDASH.aspx");
                }
            }
            else if (DropDownList2.SelectedItem.Text == "HR")
            {
                cmd = new SqlCommand("select count(*) from hrdtl where hemail= '" + TextBox2.Text + "' and hpwd= '" + TextBox1.Text + "'", cn);
                i = Convert.ToInt32(cmd.ExecuteScalar());
                Response.Write(i);
                if (i == 1)
                {

                    Response.Redirect("HRDASH.aspx");
                }
            }
            else
            {
                cmd = new SqlCommand("select count(*) from empdtl where eemail= '" + TextBox2.Text + "' and epwd= '" + TextBox1.Text+"'", cn);
                i = Convert.ToInt32(cmd.ExecuteScalar());
                Response.Write(i);
                if (i == 1)
                {

                    Response.Redirect("EMPDASH.aspx");
                }
            }

                // int i = Convert.ToInt32(cmd.ExecuteNonQuery());
                // Response.Write(i);
                /*   if (i == 1)
                   {

                       Response.Redirect("ADMINDASH.aspx");
                   }

                   */

            }
    }
}