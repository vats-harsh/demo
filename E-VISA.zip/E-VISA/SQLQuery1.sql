
create table Admindtl(Aname varchar(20),Aid int primary key,Aemail varchar(20),Apwd varchar(10))
create table HRdtl(Hname varchar(20),Hid int primary key,Hemail varchar(20),Hpwd varchar(10))
create table EMPdtl(Ename varchar(20),Eid int primary key,Eemail varchar(20),Epwd varchar(10))

insert into admindtl values('admin',101,'admin@123','admin123')

create table visa(vid int,source varchar(20),destination varchar(20),sdate date,edate date,ROV varchar(30),EID int foreign key references EMPdtl(eid))
create table interview(eid int foreign key references EMPdtl(eid),idate date,istatus varchar(15))
create table feedback(id int,name varchar(20),fb varchar(50))

insert into empdtl values('Punit',11,'punit@123','punit123')